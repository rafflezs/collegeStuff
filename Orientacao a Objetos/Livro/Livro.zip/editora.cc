#include "editora.h"

Editora::Editora(Endereco* endereco){

}

string Editora::getNome(){
    return this->nome;
}

void Editora::setNome(const string & temp){
    this->nome = nome;
}