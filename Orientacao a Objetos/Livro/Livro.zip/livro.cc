#include "livro.h"

Livro::Livro(vector<Capitulo*> capitulos, Editora* editora,Autor* autor){

};