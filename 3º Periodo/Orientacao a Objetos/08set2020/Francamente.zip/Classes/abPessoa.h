#ifndef _ABPESSOA_H
#define _ABPESSOA_H

class abPessoa{

    public:
        virtual void salvar() = 0;
        virtual ~abPessoa(){};
};

#endif